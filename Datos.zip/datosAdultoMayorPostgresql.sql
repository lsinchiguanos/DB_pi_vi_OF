/* EJECUTAR ESTA CONSULTA PRIMERO */
SELECT * FROM public.usuario WHERE rol = 'AD'

/* COLOCAR LOS ID DE LOS USUARIOS DE LA CONSULTA */
INSERT INTO public.adulto_mayor
(id_usuario)
VALUES
(2);

INSERT INTO public.adulto_mayor
(id_usuario)
VALUES
(5);

INSERT INTO public.adulto_mayor
(id_usuario)
VALUES
(6);

INSERT INTO public.adulto_mayor
(id_usuario)
VALUES
(7);