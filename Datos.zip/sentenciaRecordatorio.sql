SELECT re.titulo, re.fecha_recordar, re.fecha_limite
	FROM public.recordatorio re
	WHERE re.id_usuario_creador = 2 OR re.id_usuario_receptor = 2 AND
		  re.estado LIKE 'Activo' AND
		  extract(hour from((re.fecha_recordar::timestamp)-(now()::timestamp))::interval) <= re.hora_frecuente_aviso AND
		  extract(hour from((re.fecha_recordar::timestamp)-(now()::timestamp))::interval) >= 0
	
SELECT *
	FROM public.recordatorio re
	WHERE re.id_usuario_creador = 2 OR re.id_usuario_receptor = 2 AND re.estado LIKE 'Activo'
	
Select extract(hour from(('2020-02-06 10:45:00'::timestamp)-(now()::timestamp))::interval)