SELECT * FROM public.recordatorio

SELECT recordatorio.id,
	   recordatorio.id_usuario_creador,
	   recordatorio.id_usuario_receptor,
	   recordatorio.titulo,
	   recordatorio.fecha_recordar,
	   recordatorio.fecha_limite,
	   recordatorio.hora_recordatorio,
	   recordatorio.dia_duracion_aviso,
	   recordatorio.hora_frecuente_aviso,
	   recordatorio.tiempo_pre_notificacion,
	   recordatorio.tiempo_pos_aviso,
	   recordatorio.descripcion,
	   recordatorio.color
	FROM public.recordatorio WHERE recordatorio.estado = 'Activo'

INSERT INTO public.recordatorio
(id_usuario_creador,
id_usuario_receptor,
titulo,
fecha_recordar,
fecha_limite,
hora_recordatorio,
dia_duracion_aviso,
hora_frecuente_aviso,
tiempo_pre_notificacion,
tiempo_pos_aviso,
descripcion,
color)
VALUES
(1,
2,
'Tomar médicamento',
'2020-02-02 08:20',
'2020-02-05 08:25',
'08:20',
5,
3,
5,
5,
'Tomar paracetamol de 500gr antes de cada desayuno',
'#ffcccc');

INSERT INTO public.recordatorio
(id_usuario_creador,
id_usuario_receptor,
titulo,
fecha_recordar,
fecha_limite,
hora_recordatorio,
dia_duracion_aviso,
hora_frecuente_aviso,
tiempo_pre_notificacion,
tiempo_pos_aviso,
descripcion,
color)
VALUES
(1,
2,
'Tomar médicamento',
'2020-02-07 08:20',
'2020-02-10 08:25',
'08:20',
5,
3,
5,
5,
'Tomar diarren de 500gr antes de cada desayuno',
'#ffcccc');