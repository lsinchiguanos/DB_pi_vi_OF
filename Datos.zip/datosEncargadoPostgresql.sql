/*EJECUTAR ESTA CONSULTA PRIMERO*/
SELECT * FROM public.usuario WHERE rol = 'CP'

INSERT INTO public.encargado
(id_adulto_mayor,
id_usuario,
parentesco,
direccion_trabajo,
telefono_trabajo,
extensionc)
VALUES
(1,
1,
'Hijo',
'Buena Fe',
'0960037739',
'000');

INSERT INTO public.encargado
(id_adulto_mayor,
id_usuario,
parentesco,
direccion_trabajo,
telefono_trabajo,
extensionc)
VALUES
(1,
3,
'Hijo',
'Buena Fe',
'0960037739',
'000');

SELECT * FROM public.encargado