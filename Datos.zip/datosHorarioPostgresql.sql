SELECT * FROM public.usuario

SELECT * FROM public.horario

INSERT INTO public.horario
(id_usuario,
tiempo_aviso)
VALUES
(1,
60);

SELECT * FROM public.horario_detalle

INSERT INTO public.horario_detalle
(id_horario,
dia,
numero_dia,
hora_inicio,
hora_fin,
descripcion,
color)
VALUES
(2,
'Lunes',
1,
'12:30',
'13:30',
'Sistemas de Comunicación de Datos',
'#ffff99');


INSERT INTO public.horario_detalle
(id_horario,
dia,
numero_dia,
hora_inicio,
hora_fin,
descripcion,
color)
VALUES
(2,
'Martes',
 2,
'09:30',
'11:30',
'Sistemas de Comunicación de Datos',
'#ffff99');

INSERT INTO public.horario_detalle
(id_horario,
dia,
numero_dia,
hora_inicio,
hora_fin,
descripcion,
color)
VALUES
(2,
'Martes',
 2,
'11:30',
'13:30',
'Microcontroladores',
'#66ffcc');

INSERT INTO public.horario_detalle
(id_horario,
dia,
numero_dia,
hora_inicio,
hora_fin,
descripcion,
color)
VALUES
(2,
'Martes',
 2,
'14:30',
'17:30',
'Tecnología del Internet',
'#33cccc');

INSERT INTO public.horario_detalle
(id_horario,
dia,
numero_dia,
hora_inicio,
hora_fin,
descripcion,
color)
VALUES
(2,
'Martes',
 2,
'17:30',
'19:30',
'Sistemas de Información',
'#009999');

INSERT INTO public.horario_detalle
(id_horario,
dia,
numero_dia,
hora_inicio,
hora_fin,
descripcion,
color)
VALUES
(2,
'Miércoles',
 3,
'11:30',
'13:30',
'Microcontroladores',
'#66ffcc');

INSERT INTO public.horario_detalle
(id_horario,
dia,
numero_dia,
hora_inicio,
hora_fin,
descripcion,
color)
VALUES
(2,
'Miércoles',
 3,
'18:30',
'20:30',
'Coordinación de Proyecto Modulo VI',
'#ff9999');

INSERT INTO public.horario_detalle
(id_horario,
dia,
numero_dia,
hora_inicio,
hora_fin,
descripcion,
color)
VALUES
(2,
'Jueves',
 4,
'11:30',
'13:30',
'Sistemas de Comunicación de Datos',
'#ffff99');

INSERT INTO public.horario_detalle
(id_horario,
dia,
numero_dia,
hora_inicio,
hora_fin,
descripcion,
color)
VALUES
(2,
'Jueves',
 4,
'14:30',
'16:30',
'Tecnología del Internet',
'#33cccc');

INSERT INTO public.horario_detalle
(id_horario,
dia,
numero_dia,
hora_inicio,
hora_fin,
descripcion,
color)
VALUES
(2,
'Viernes',
 5,
'16:30',
'18:30',
'Sistemas de Información',
'#009999');

SELECT * FROM public.horario_detalle