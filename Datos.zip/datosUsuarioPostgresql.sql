INSERT INTO public.usuario
(cedula,
nombres,
apellidos,
fecha_nacimiento,
correo_electronico,
numero_celular,
direccion_vivienda,
username,
contrasenia,
rol)
VALUES
('1205388547',
'Leslie Alexander',
'Sinchiguano Saltos',
'1997-08-08',
'lesliesinchiguano@gmail.com',
'0960037739',
'Coop. 19 de Octubre, Manuel Nogales y Cuenca',
'lsinchiguanos',
'2ku4BUfTAxRIUU3rewWGYA==',
'CP');

INSERT INTO public.usuario
(cedula,
nombres,
apellidos,
fecha_nacimiento,
correo_electronico,
numero_celular,
direccion_vivienda,
username,
contrasenia,
rol)
VALUES
('1500112402',
'Cesar Augusto',
'Sinchiguano Taipe',
'1956-07-11',
'absinchiguano@hotmail.com',
'0999125647',
'Coop. 19 de Octubre, Manuel Nogales y Cuenca',
'absinchiguano23',
'2ku4BUfTAxRIUU3rewWGYA==',
'AD');

INSERT INTO public.usuario
(cedula,
nombres,
apellidos,
fecha_nacimiento,
correo_electronico,
numero_celular,
direccion_vivienda,
username,
contrasenia,
rol)
VALUES
('1205388562',
'Bexy Yadira',
'Sinchiguano Saltos',
'1989-04-25',
'bexyyadira89@hotmail.com',
'0960037739',
'Coop. 19 de Octubre, Manuel Nogales y Cuenca',
'bsinchiguano89',
'2ku4BUfTAxRIUU3rewWGYA==',
'CP');


INSERT INTO public.usuario
(cedula,
nombres,
apellidos,
fecha_nacimiento,
correo_electronico,
numero_celular,
direccion_vivienda,
username,
contrasenia,
rol)
VALUES
('1206520288',
'Byron Javier',
'Paredes Miranda',
'1997-04-25',
'byronmiranda97@hotmail.com',
'0969977030',
'Coop. 19 de Octubre, Manuel Nogales y Cuenca',
'bparedes',
'2ku4BUfTAxRIUU3rewWGYA==',
'CP');


INSERT INTO public.usuario
(cedula,
nombres,
apellidos,
fecha_nacimiento,
correo_electronico,
numero_celular,
direccion_vivienda,
username,
contrasenia,
rol)
VALUES
('1253388404',
'Marlon Javier',
'Torres Jaramillo',
'1956-04-26',
'mtjaramillo97@hotmail.com',
'0967724052',
'Coop. 19 de Octubre, Manuel Nogales y Cuenca',
'mtorres56',
'2ku4BUfTAxRIUU3rewWGYA==',
'AD');

INSERT INTO public.usuario
(cedula,
nombres,
apellidos,
fecha_nacimiento,
correo_electronico,
numero_celular,
direccion_vivienda,
username,
contrasenia,
rol)
VALUES
('1234567890',
'Josep Manuel',
'Pelegrini Peralta',
'1990-04-26',
'pelegrini9005@hotmail.com',
'0967724052',
'Coop. 19 de Octubre, Manuel Nogales y Cuenca',
'pelegriniol90',
'2ku4BUfTAxRIUU3rewWGYA==',
'AD');

INSERT INTO public.usuario
(cedula,
nombres,
apellidos,
fecha_nacimiento,
correo_electronico,
numero_celular,
direccion_vivienda,
username,
contrasenia,
rol)
VALUES
('0903456789',
'Jon Jairo',
'Cifuentes Loor',
'1956-04-26',
'jfuentes56@hotmail.com',
'0967724052',
'Coop. 19 de Octubre, Manuel Nogales y Cuenca',
'jfuentes90',
'2ku4BUfTAxRIUU3rewWGYA==',
'AD');